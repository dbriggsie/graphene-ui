'use strict';

require('./tasks/release');
